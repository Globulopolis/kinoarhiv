<?php defined('_JEXEC') or die; ?>
<div id="j-main-container" class="control-panel">
	<a class="btn" href="index.php?option=com_kinoarhiv&view=movies"><span class="icon-play"> </span> <?php echo JText::_('COM_KA_MOVIES_TITLE'); ?></a>
	<a class="btn" href="index.php?option=com_kinoarhiv&view=names"><span class="icon-users"> </span> <?php echo JText::_('COM_KA_NAMES_TITLE'); ?></a>
	<a class="btn" href="index.php?option=com_kinoarhiv&view=genres"><span class="icon-smiley-2"> </span> <?php echo JText::_('COM_KA_GENRES_TITLE'); ?></a>
	<a class="btn" href="index.php?option=com_kinoarhiv&view=countries"><span class="icon-location"> </span> <?php echo JText::_('COM_KA_COUNTRIES_TITLE'); ?></a>
	<a class="btn" href="index.php?option=com_kinoarhiv&view=settings"><span class="icon-options"> </span> <?php echo JText::_('COM_KA_SETTINGS_TITLE'); ?></a>
</div>
